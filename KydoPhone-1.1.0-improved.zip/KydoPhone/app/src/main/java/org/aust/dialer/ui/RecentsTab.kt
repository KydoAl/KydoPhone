package org.aust.dialer.ui

import android.Manifest
import android.provider.CallLog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Voicemail
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.aust.dialer.DialerViewModel
import org.aust.dialer.R
import org.aust.dialer.core.Format
import org.aust.dialer.core.Intents
import org.aust.dialer.core.PhoneUtils
import org.aust.dialer.data.CallGroup
import org.aust.dialer.data.CallLogEntry
import org.aust.dialer.data.Contact
import org.aust.dialer.telecom.CallNotifications

private fun typeIcon(type: Int): ImageVector = when (type) {
    CallLog.Calls.OUTGOING_TYPE -> Icons.AutoMirrored.Filled.CallMade
    CallLog.Calls.MISSED_TYPE -> Icons.AutoMirrored.Filled.CallMissed
    CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> Icons.Default.Block
    CallLog.Calls.VOICEMAIL_TYPE -> Icons.Default.Voicemail
    else -> Icons.AutoMirrored.Filled.CallReceived
}

private fun typeLabel(type: Int): Int = when (type) {
    CallLog.Calls.OUTGOING_TYPE -> R.string.call_outgoing
    CallLog.Calls.MISSED_TYPE -> R.string.call_missed
    CallLog.Calls.REJECTED_TYPE -> R.string.call_rejected
    CallLog.Calls.BLOCKED_TYPE -> R.string.call_blocked
    CallLog.Calls.VOICEMAIL_TYPE -> R.string.call_voicemail
    else -> R.string.call_incoming
}

@Composable
fun RecentsTab(vm: DialerViewModel, listState: LazyListState, onOpenContact: (Long) -> Unit) {
    val context = LocalContext.current
    val recents by vm.recents.collectAsState()
    val index by vm.contactIndex.collectAsState()
    val perms by vm.perms.collectAsState()
    val callController = LocalCallController.current
    val snackbar = LocalSnackbar.current
    val scope = rememberCoroutineScope()
    var sheetFor by remember { mutableStateOf<CallGroup?>(null) }
    var confirmDelete by remember { mutableStateOf<CallGroup?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var missedOnly by rememberSaveable { mutableStateOf(false) }

    val requestCallLog = rememberPermissionRequester(vm, arrayOf(Manifest.permission.READ_CALL_LOG))
    val requestWrite = rememberPermissionRequester(vm, arrayOf(Manifest.permission.WRITE_CALL_LOG))
    val deletedMsg = stringResource(R.string.recents_deleted)
    val deleteFailedMsg = stringResource(R.string.recents_delete_failed)
    val copiedMsg = stringResource(R.string.number_copied)
    val noSmsMsg = stringResource(R.string.error_no_sms_app)

    LaunchedEffect(perms.callLog) {
        if (perms.callLog) {
            vm.markMissedRead()
            CallNotifications.cancelMissed(context)
        }
    }

    if (!perms.callLog) {
        MessageCard(stringResource(R.string.recents_permission_text), stringResource(R.string.action_grant), requestCallLog)
    } else if (recents.isEmpty()) {
        EmptyState(Icons.Default.History, stringResource(R.string.recents_empty))
    } else {
        val filtered = remember(recents, search, missedOnly, index) {
            val q = search.trim().lowercase()
            recents.filter { group ->
                val e = group.first
                val contact = index.findByNumber(e.number)
                val title = contact?.name ?: e.cachedName.orEmpty()
                val matchesSearch = q.isEmpty() ||
                    title.lowercase().contains(q) ||
                    group.entries.any {
                        Format.number(it.number).lowercase().contains(q) ||
                            it.number.contains(q)
                    }
                val matchesMissed = !missedOnly || group.entries.any { it.type == CallLog.Calls.MISSED_TYPE }
                matchesSearch && matchesMissed
            }
        }
        Column(Modifier.fillMaxSize()) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true,
                placeholder = { Text(stringResource(R.string.recents_search_hint)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            )
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = missedOnly,
                    onClick = { missedOnly = !missedOnly },
                    label = { Text(stringResource(R.string.recents_missed_filter)) },
                )
            }
            if (filtered.isEmpty()) {
                EmptyState(Icons.Default.History, stringResource(R.string.recents_no_matches), modifier = Modifier.weight(1f))
            } else {
                LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
            items(filtered, key = { it.key }) { group ->
                val e = group.first
                val contact = index.findByNumber(e.number)
                val unknown = PhoneUtils.isUnknown(e.number)
                val title = contact?.name ?: e.cachedName
                    ?: if (unknown) stringResource(R.string.recents_private) else Format.number(e.number)
                val missed = e.type == CallLog.Calls.MISSED_TYPE
                ListItem(
                    modifier = Modifier.clickable(onClickLabel = stringResource(R.string.action_call)) {
                        if (!unknown) callController.call(e.number)
                    },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    leadingContent = { Avatar(contact?.name ?: e.cachedName, contact?.thumbUri ?: e.cachedPhoto, 44.dp) },
                    headlineContent = {
                        Text(
                            if (group.count > 1) "$title (${group.count})" else title,
                            maxLines = 1,
                            color = if (missed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                        )
                    },
                    supportingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                typeIcon(e.type),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (missed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                "  " + stringResource(typeLabel(e.type)) + " · " + Format.callTime(context, e.date),
                                maxLines = 1,
                            )
                        }
                    },
                    trailingContent = {
                        IconButton(onClick = { sheetFor = group }) {
                            Icon(Icons.Default.Info, contentDescription = stringResource(R.string.action_details))
                        }
                    },
                )
                }
            }
        }
    }

    sheetFor?.let { group ->
        val e = group.first
        val contact = index.findByNumber(e.number)
        CallDetailsSheet(
            group = group,
            contact = contact,
            onDismiss = { sheetFor = null },
            onCall = {
                sheetFor = null
                callController.call(e.number)
            },
            onMessage = {
                sheetFor = null
                if (!Intents.message(context, e.number)) scope.launch { snackbar.showSnackbar(noSmsMsg) }
            },
            onContact = {
                sheetFor = null
                if (contact != null) onOpenContact(contact.id) else Intents.addContact(context, e.number)
            },
            onCopy = {
                sheetFor = null
                Intents.copyNumber(context, e.number)
                scope.launch { snackbar.showSnackbar(copiedMsg) }
            },
            onDelete = {
                sheetFor = null
                if (perms.writeCallLog) confirmDelete = group else requestWrite()
            },
        )
    }

    confirmDelete?.let { group ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text(stringResource(R.string.recents_delete_title)) },
            text = { Text(stringResource(R.string.recents_delete_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = null
                    vm.deleteCalls(group) { ok ->
                        scope.launch { snackbar.showSnackbar(if (ok) deletedMsg else deleteFailedMsg) }
                    }
                }) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CallDetailsSheet(
    group: CallGroup,
    contact: Contact?,
    onDismiss: () -> Unit,
    onCall: () -> Unit,
    onMessage: () -> Unit,
    onContact: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit,
) {
    val context = LocalContext.current
    val e = group.first
    val unknown = PhoneUtils.isUnknown(e.number)
    val name = contact?.name ?: e.cachedName
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState()) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            ListItem(
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { Avatar(name, contact?.thumbUri ?: e.cachedPhoto, 48.dp) },
                headlineContent = {
                    Text(name ?: if (unknown) stringResource(R.string.recents_private) else Format.ltr(Format.number(e.number)))
                },
                supportingContent = {
                    if (name != null && !unknown) Text(Format.ltr(Format.number(e.number)))
                },
            )
            HorizontalDivider()
            for (entry in group.entries.take(8)) {
                CallEntryRow(entry, context)
            }
            HorizontalDivider()
            if (!unknown) {
                SheetAction(Icons.Default.Call, R.string.action_call, onCall)
                SheetAction(Icons.AutoMirrored.Filled.Message, R.string.action_message, onMessage)
                if (contact != null) {
                    SheetAction(Icons.Default.Person, R.string.action_details, onContact)
                } else {
                    SheetAction(Icons.Default.PersonAdd, R.string.action_add_contact, onContact)
                }
                SheetAction(Icons.Default.ContentCopy, R.string.action_copy, onCopy)
            }
            SheetAction(Icons.Default.Delete, R.string.action_delete, onDelete)
        }
    }
}

@Composable
private fun CallEntryRow(entry: CallLogEntry, context: android.content.Context) {
    ListItem(
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = { Icon(typeIcon(entry.type), contentDescription = null) },
        headlineContent = { Text(stringResource(typeLabel(entry.type))) },
        supportingContent = { Text(Format.callTime(context, entry.date)) },
        trailingContent = {
            if (entry.durationSec > 0) Text(Format.duration(entry.durationSec))
        },
    )
}

@Composable
private fun SheetAction(icon: ImageVector, label: Int, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = { Icon(icon, contentDescription = null) },
        headlineContent = { Text(stringResource(label)) },
    )
}
