package org.aust.dialer.ui

import android.Manifest
import android.telecom.PhoneAccountHandle
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.launch
import org.aust.dialer.DialerViewModel
import org.aust.dialer.IntentRequest
import org.aust.dialer.R
import org.aust.dialer.core.Prefs
import org.aust.dialer.telecom.CallPlacer
import org.aust.dialer.telecom.SimAccount

@Composable
fun AppRoot(vm: DialerViewModel, prefs: Prefs, request: IntentRequest?, onConsumed: () -> Unit) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val controller = remember { CallController() }
    val nav = rememberNavController()

    var tab by rememberSaveable { mutableIntStateOf(TAB_RECENTS) }
    var number by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue("")) }

    var pendingNumber by remember { mutableStateOf<String?>(null) }
    var simChoice by remember { mutableStateOf<Pair<String, List<SimAccount>>?>(null) }

    val errCall = stringResource(R.string.error_call_failed)
    val errPerm = stringResource(R.string.error_no_call_permission)

    fun show(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun place(n: String, handle: PhoneAccountHandle?) {
        when (CallPlacer.place(context, n, handle)) {
            CallPlacer.Result.OK, CallPlacer.Result.INVALID -> Unit
            CallPlacer.Result.NO_PERMISSION -> show(errPerm)
            CallPlacer.Result.ERROR -> show(errCall)
        }
    }

    // Multi-SIM: use the system's "always use this SIM" choice when set, otherwise ask.
    fun proceed(n: String) {
        val accounts = CallPlacer.simAccounts(context)
        val def = CallPlacer.defaultAccount(context)
        if (accounts.size > 1 && def == null) simChoice = n to accounts else place(n, def)
    }

    val callPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshPermissions()
        val n = pendingNumber
        pendingNumber = null
        if (n != null) {
            if (CallPlacer.hasCallPermission(context)) proceed(n) else show(errPerm)
        }
    }

    fun startCall(n: String) {
        if (n.isBlank()) return
        if (CallPlacer.hasCallPermission(context) && CallPlacer.hasPhoneStatePermission(context)) {
            proceed(n)
        } else {
            pendingNumber = n
            callPermLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE))
        }
    }

    SideEffect { controller.impl = { n -> startCall(n) } }

    // Intents from outside (tel: links, notification actions).
    LaunchedEffect(request) {
        val r = request ?: return@LaunchedEffect
        r.tab?.let { tab = it }
        r.number?.let { number = TextFieldValue(it, TextRange(it.length)) }
        val route = nav.currentDestination?.route
        if (route == "contact/{id}" || route == "speeddial" || route == "settings") {
            nav.popBackStack("home", false)
        }
        r.callNumber?.let { startCall(it) }
        onConsumed()
    }

    CompositionLocalProvider(LocalCallController provides controller, LocalSnackbar provides snackbar) {
        val slide = AnimatedContentTransitionScope.SlideDirection.Start
        val slideBack = AnimatedContentTransitionScope.SlideDirection.End
        NavHost(
            nav,
            startDestination = if (prefs.setupDone) "home" else "setup",
            // Direction-aware: slides the right way in Arabic (RTL) too.
            enterTransition = { slideIntoContainer(slide, tween(320)) + fadeIn(tween(320)) },
            exitTransition = { slideOutOfContainer(slide, tween(320), targetOffset = { it / 4 }) + fadeOut(tween(320)) },
            popEnterTransition = { slideIntoContainer(slideBack, tween(320), initialOffset = { it / 4 }) + fadeIn(tween(320)) },
            popExitTransition = { slideOutOfContainer(slideBack, tween(320)) + fadeOut(tween(320)) },
        ) {
            composable("setup") {
                SetupScreen(vm, onDone = {
                    prefs.setupDone = true
                    nav.navigate("home") { popUpTo("setup") { inclusive = true } }
                })
            }
            composable("home") {
                HomeScreen(vm, tab, { tab = it }, number, { number = it }, nav)
            }
            composable("contact/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                ContactDetailScreen(vm, entry.arguments?.getLong("id") ?: -1L, onBack = { nav.popBackStack() })
            }
            composable("speeddial") {
                SpeedDialScreen(vm, onBack = { nav.popBackStack() })
            }
            composable("settings") {
                SettingsScreen(vm, onBack = { nav.popBackStack() }, onSpeedDial = { nav.navigate("speeddial") })
            }
        }

        simChoice?.let { (n, accounts) ->
            SimPickerDialog(
                accounts = accounts,
                onPick = { account ->
                    simChoice = null
                    place(n, account.handle)
                },
                onDismiss = { simChoice = null },
            )
        }
    }
}
